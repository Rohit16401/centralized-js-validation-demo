﻿// /Scripts/validation.js
// Small reusable validation engine that uses data-type attributes.
// - validateField($el) validates a single jQuery element
// - validateAll(selector) validates all elements matched by selector
// - registerRule(type, fn) allows adding custom rules

(function (global, $) {
    if (!$) throw new Error("jQuery is required for validation.js");

    console.log("✅ validation.js loaded");

    // rule functions map: return { ok: boolean, message: string }
    const rules = {};

    // built-in rules
    registerRule("required", (value) => {
        return value === "" ? { ok: false, message: "This field is required." } : { ok: true };
    });

    registerRule("name", (value) => {
        if (value.length < 3) return { ok: false, message: "At least 3 characters required." };
        if (!/^[A-Za-z ]+$/.test(value)) return { ok: false, message: "Only letters and spaces allowed." };
        return { ok: true };
    });

    registerRule("email", (value) => {
        const p = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
        return p.test(value) ? { ok: true } : { ok: false, message: "Enter a valid email address." };
    });

    

    registerRule("number", (value) => {
        return /^\d+$/.test(value) ? { ok: true } : { ok: false, message: "Only numeric values allowed." };
    });

    registerRule("text", (value) => {
        return value === "" ? { ok: false, message: "This field cannot be empty." } : { ok: true };
    });

    // Register a new rule programmatically
    function registerRule(type, fn) {
        rules[type] = fn;
    }

    // Validate a single field (jQuery element)
    function validateField($el) {
        // Identify error span by convention: <input id="foo"> -> <span id="foo-error">
        const id = $el.attr("id");
        if (!id) return true; // Can't show error without id, treat as valid
        const $error = $("#" + id + "-error");
        $error.text("");

        const raw = ($el.val() || "").toString().trim();
        const types = ($el.data("type") || "").toString().split("|").map(s => s.trim()).filter(Boolean);

        // allow an attribute data-required="true" to enforce required even without data-type
        if (($el.data("required") === true || $el.data("required") === "true") && raw === "") {
            $error.text("This field is required.");
            $el.addClass("invalid-field");
            return false;
        }

        // Run types in order; stop on first failure
        for (let t of types) {
        // support paramized types like min:3 or pattern:^\d+$
            if (t.indexOf(":") > -1) {
                const [base, param] = t.split(/:(.+)/); // split only first colon
                if (base === "min") {
                    const min = parseInt(param, 10);
                    if (raw.length < min) {
                        $error.text(`Minimum ${min} characters required.`);
                        $el.addClass("invalid-field");
                        return false;
                    } else {
                        continue;
                    }
                }
                if (base === "pattern") {
                    let regex;
                    try { regex = new RegExp(param); } catch (err) { continue; }
                    if (!regex.test(raw)) {
                        $error.text("Invalid format.");
                        $el.addClass("invalid-field");
                        return false;
                    } else continue;
                }
            }

        // normal rule
            const ruleFn = rules[t];
            if (!ruleFn) continue; // unknown rule -> skip
            const result = ruleFn(raw);
            if (!result.ok) {
                $error.text(result.message || "Invalid value.");
                $el.addClass("invalid-field");
                return false;
            }
        }

        // passed all checks
        $el.removeClass("invalid-field");
        $error.text("");
        return true;
    }

    // Validate all elements matched by selector (eg "#employeeForm [data-type]" or "[data-type]")
    function validateAll(selectorOrContainer) {
        let $els;
        if (typeof selectorOrContainer === "string") {
            // if container selector, find data-type inside
            $els = $(`${selectorOrContainer} [data-type]`);
            if ($els.length === 0) $els = $(selectorOrContainer).filter("[data-type]");
        } else {
            $els = $("[data-type]");
        }

        let ok = true;
        $els.each(function () {
            const $f = $(this);
            const fieldOk = validateField($f);
            if (!fieldOk) ok = false;
        });
        return ok;
    }

    // Expose API
    global.ValidationEngine = {
        registerRule,
        validateField: function (elOrSelector) {
            const $el = (elOrSelector instanceof $) ? elOrSelector : $(elOrSelector);
            if ($el.length === 0) return true;
            return validateField($el.eq(0));
        },
        validateAll
    };

})(window, window.jQuery);
